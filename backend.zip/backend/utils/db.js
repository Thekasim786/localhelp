require("dotenv").config();
const mongoose = require("mongoose");
const URI_Customer = process.env.MONGODB_URI_customer;

const connectDb = async () => {
  try {
    await mongoose.connect(URI_Customer, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      
    }
);
    console.log("✅ MongoDB Atlas connected successfully!");
    console.log("Mongo URI:", URI_Customer);

  } catch (error) {
    console.error("❌ Database connection failed:", error);
    process.exit(0);
    console.log("Mongo URI:", process.env.MONGO_URI);

  }
};

module.exports = connectDb;
