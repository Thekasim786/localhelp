const express = require('express');
const router = express.Router();

// Mock user data for demonstration
const mockUsers = {
  'customer@nukkadhelp.com': {
    id: 1,
    email: 'customer@nukkadhelp.com',
    password: 'customer123',
    name: 'John Customer',
    role: 'customer'
  },
  'provider@nukkadhelp.com': {
    id: 2,
    email: 'provider@nukkadhelp.com',
    password: 'provider123',
    name: 'Mike Provider',
    role: 'provider'
  }
};

// Login endpoint
router.post('/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ 
      success: false, 
      message: 'Email and password are required' 
    });
  }

  const user = mockUsers[email];
  
  if (!user || user.password !== password) {
    return res.status(401).json({ 
      success: false, 
      message: 'Invalid credentials' 
    });
  }

  // Remove password from response
  const { password: _, ...userWithoutPassword } = user;
  
  res.json({
    success: true,
    message: 'Login successful',
    user: userWithoutPassword
  });
});

// Logout endpoint
router.post('/logout', (req, res) => {
  // In a real application, you would:
  // 1. Invalidate JWT tokens in a blacklist
  // 2. Clear server-side sessions
  // 3. Log the logout event
  
  res.json({
    success: true,
    message: 'Logout successful'
  });
});

// Register endpoint (for future use)
router.post('/register', (req, res) => {
  const { email, password, name, role } = req.body;

  if (!email || !password || !name || !role) {
    return res.status(400).json({ 
      success: false, 
      message: 'All fields are required' 
    });
  }

  if (mockUsers[email]) {
    return res.status(409).json({ 
      success: false, 
      message: 'User already exists' 
    });
  }

  const newUser = {
    id: Object.keys(mockUsers).length + 1,
    email,
    password,
    name,
    role
  };

  mockUsers[email] = newUser;

  // Remove password from response
  const { password: _, ...userWithoutPassword } = newUser;
  
  res.status(201).json({
    success: true,
    message: 'Registration successful',
    user: userWithoutPassword
  });
});

// Verify token endpoint (for future JWT implementation)
router.get('/verify', (req, res) => {
  // In a real application, you would verify JWT tokens here
  res.json({
    success: true,
    message: 'Token is valid'
  });
});

module.exports = router;


